export type Department = 'IT' | 'HR' | 'Finance' | 'Procurement' | 'Marketing';

export const DEPARTMENTS: Department[] = ['IT', 'HR', 'Finance', 'Procurement', 'Marketing'];
